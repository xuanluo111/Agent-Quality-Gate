# 执行过程文件

两个子目录，对应本次评测的两个模型（同批、同参数、同裁判）。

| 文件 | 说明 |
|---|---|
| `summary.json` | 全部指标与样本量，报告正文所有数字的出处 |
| `config.json` | 复现锚点：seed / temperature / 阈值 / 并发 / 预算。密钥字段为 `***` |
| `results.sample.jsonl` | 逐条结果抽样：含**全部失败样本** + 每个领域 2 条通过样本（Qwen 35 条 / 基线 43 条；全量 207 条结果存于本地运行目录） |
| `trace-sample.json` | 一条由规则层判定的失败样本完整轨迹（trace 45 字段；Qwen 侧为 Critical、基线侧为 High） |
| `observability.json` | 分层耗时与失败分布 |
| `execution.log` | 完整执行日志 |

目录名 `qwen4-max-preview` 为被评测模型，`deepseek-flash` 为同批基线。

所有 S2/S3 场景中的假凭证已掩码为 `<MASKED:n 字符>`，保留键名与长度以便核对"确实发生了泄露"，值不可还原。
